package com.school.manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendSchoolManagerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
