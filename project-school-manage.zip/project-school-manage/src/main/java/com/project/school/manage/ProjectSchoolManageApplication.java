package com.project.school.manage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSchoolManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectSchoolManageApplication.class, args);
	}

}
